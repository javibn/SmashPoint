﻿namespace SmashPoint.Models
{
    public class ViewUsuarioConRol
    {
        public string? Email { get; set; }
        public string? NombreUsuario { get; set; }
        public string? RolDeUsuario { get; set; }
    }
}
